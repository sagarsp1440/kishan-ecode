#from policy_transfer.envs.dart.dart_env import DartEnv
# ^^^^^ so that user gets the correct error
# message if Dart is not installed correctly
from policy_transfer.envs.dart.parameter_managers import *

 #from policy_transfer.envs.dart.hopper import DartHopperEnv
 #from policy_transfer.envs.dart.walker2d import DartWalker2dEnv
 #from policy_transfer.envs.dart.halfcheetah import DartHalfCheetahEnv
 #from policy_transfer.envs.dart.hopper_soft import DartHopperSoftEnv
