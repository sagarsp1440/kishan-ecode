

class Hopper:
    def __init__(name):
        self.name = name
    def construct_xml(xml_path, folder_path):
        print("Constructing xml")


